﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

/*
 	App name:Mail Order;   	
    Author's name: Kartik khurana;
    Creation Date; 2017.1.27
    App description: Calculating the amount of bonus each employee receives based upon percentage of hours
                    during the bonus period.
     
     
    */
namespace MailOrder
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            EmployeeName.Text = "";
            EmployeeId.Text = "";
            HoursWorked.Text = "0";
            TotalSales.Text = "0";
            SalesBonus.Text = "0";
        }

        private void CalculateButton_Click(object sender, EventArgs e)
        {
            /* variables = actualname
            percofhoursworked = percentageofhoursworked
            totalbonusamt = totalbonusamount
            salesbonus = sales bonus

          */
            double percofhoursworked = double.Parse(HoursWorked.Text) / 160;
            double totalbonusamt = double.Parse(TotalSales.Text) * 0.02;
            double salesbonus = percofhoursworked * totalbonusamt;
            SalesBonus.Text = salesbonus.ToString("");
        }

        private void PrintButton_Click(object sender, EventArgs e)
        {
            MessageBox.Show("The form is being sent to the Printer :)");
        }

        private void HoursWorked_TextChanged(object sender, EventArgs e)
        {
            int kk;
            if (!int.TryParse(HoursWorked.Text, out kk)) 
            {
                MessageBox.Show("Please Enter The Number :( ");
                HoursWorked.Text = "0";
            }
            if(int.Parse(HoursWorked.Text)>160)
            {
                MessageBox.Show("The hours worked cannot be more than 160 ");
                HoursWorked.Text = "0";
            }
            if(int.Parse(HoursWorked.Text)<0)
            {
                MessageBox.Show("The hours worked cannot be a Negative Number");
                HoursWorked.Text = "0";
            }
        }

        private void TotalSales_TextChanged(object sender, EventArgs e)
        {
            double kk;
            if(!double.TryParse(TotalSales.Text,out kk))
            {
                MessageBox.Show("Please Enter the Valid Number");
                TotalSales.Text = "0";
            }
        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            label1.Text = "Nom de l'employé ";
            label2.Text = "ID de l'employé ";
            label3.Text = "DURÉE DU TRAVAIL ";
            label4.Text = "Ventes total";
            label5.Text = "Prime ";
            CalculateButton.Text = "Calculer les frais d'expédition ";
            PrintButton.Text = "Bouton d'impression ";
            ClearButton.Text = "Bouton d'effacement ";
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            label1.Text = "Employee Name ";
            label2.Text = "Employee Id ";
            label3.Text = "Hours Worked ";
            label4.Text = "Total Sales";
            label5.Text = "Sales Bonus ";
            CalculateButton.Text = "Calculate Button ";
            PrintButton.Text = "Print Button ";
            ClearButton.Text = "Clear Button ";
        }

        private void radioButton3_CheckedChanged(object sender, EventArgs e)
        {
            label1.Text = "Bombre del Empleado ";
            label2.Text = "ID del Empleado ";
            label3.Text = "horas trabajadas  ";
            label4.Text = "Ventas totales";
            label5.Text = "Bonificación  ";
            CalculateButton.Text = "calcular Botón  ";
            PrintButton.Text = "escribir Botón ";
            ClearButton.Text = "despejar Botón";
        }
    }
}